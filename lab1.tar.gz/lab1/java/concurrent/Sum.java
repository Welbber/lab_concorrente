import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.*;
import java.util.Arrays;

public class Sum {
        
    public static final int QUANTI_THREADS = 5;
    
    public static void main(String[] args) throws Exception {
        
        if (args.length < 1) {
            System.err.println("Usage: java Sum filepath1 filepath2 filepathN");
            System.exit(1);
        }
        int total = args.length / QUANTI_THREADS;

        for(int i = 0; i < QUANTI_THREADS; i++){
        
            SumThread sumThread = new SumThread(Arrays.copyOfRange(args, i*total, i*total + 1));
            Thread thread = new Thread(sumThread, "thread");
            thread.start();
            thread.join();
        }


    }
    
    public static class SumThread implements Runnable {
        private final String[] paths;
        
        public SumThread(String[] paths){
            this.paths = paths;
        }
        
         public static int sum(FileInputStream fis) throws IOException {

        	int byteRead;
            int sum = 0;

             while ((byteRead = fis.read()) != -1) {
            	sum += byteRead;
            }

            return sum;
        }

        public static long sum(String path) throws IOException {

            Path filePath = Paths.get(path);
            if (Files.isRegularFile(filePath)) {
           	    FileInputStream fis = new FileInputStream(filePath.toString());
                return sum(fis);
            } else {
                throw new RuntimeException("Non-regular file: " + path);
            }
         }

        @Override
        public void run() {
            for (String path : paths) {
                try {
                    System.out.println(path + " : " + sum(path));
                } catch (Exception e ){

                }
            }
        }
    }
}
