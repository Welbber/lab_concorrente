import sys
from threading import Semaphore, Thread
import time

total_caracteres = 0

multex_quantidade_total = threading = Semaphore(1)
multex_lista_arquivos = Semaphore(1)

#semaforo = Semaphore(0)

files_sums = {}

def do_sum(path):
    semaforo.acquire()
    #print("oi estou processando")
    #time.sleep(5)
    global total_caracteres
    _sum = 0
    with open(path, 'rb') as f:
        byte = f.read(1)
        while byte:
            _sum += int.from_bytes(byte, byteorder='big', signed=False)
            byte = f.read(1)

    multex_lista_arquivos.acquire()
    if _sum in files_sums:
        files_sums[_sum].append(path)
    else:
        files_sums[_sum] = [path]
    multex_lista_arquivos.release()
    
    multex_quantidade_total.acquire()
    total_caracteres += _sum
    multex_quantidade_total.release()
    
    semaforo.release()
    
    #print(path + " : " + str(_sum))

#many error could be raised error. we don't care       
if __name__ == "__main__":
    paths = sys.argv[1:]
    global semaforo
    #print(len(paths) // 2 + 1)
    semaforo = Semaphore((len(paths) // 2) + 1)
    threads = []
    for path in paths:
        try:
            thread = Thread(target=do_sum, args=(path,))
            thread.start()
            threads.append(thread)
        except Exception as e:
            print(f"Erro ao processar {path}: {e}")
    for thread in threads:
        thread.join()
    print(f'Resultado: {total_caracteres}')
    print(f'{files_sums}')
